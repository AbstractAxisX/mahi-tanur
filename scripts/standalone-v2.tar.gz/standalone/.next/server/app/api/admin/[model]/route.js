var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/[model]/route.js")
R.c("server/chunks/[root-of-the-server]__595fb14a._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_[model]_route_actions_749d3f52.js")
R.m(22041)
module.exports=R.m(22041).exports
