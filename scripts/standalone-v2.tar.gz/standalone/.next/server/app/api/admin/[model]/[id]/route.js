var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/[model]/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__35fd209d._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_[model]_[id]_route_actions_8920f311.js")
R.m(57585)
module.exports=R.m(57585).exports
