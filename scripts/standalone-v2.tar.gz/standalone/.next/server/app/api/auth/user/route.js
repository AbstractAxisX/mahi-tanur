var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/user/route.js")
R.c("server/chunks/[root-of-the-server]__7c1c6153._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_user_route_actions_1508a899.js")
R.m(59905)
module.exports=R.m(59905).exports
