var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/admin/route.js")
R.c("server/chunks/[root-of-the-server]__0e470cd0._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_admin_route_actions_3e0a8b67.js")
R.m(10766)
module.exports=R.m(10766).exports
