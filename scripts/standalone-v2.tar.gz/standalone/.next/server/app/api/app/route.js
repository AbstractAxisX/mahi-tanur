var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/app/route.js")
R.c("server/chunks/[root-of-the-server]__cb0bed79._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_app_route_actions_d1b2598e.js")
R.m(80179)
module.exports=R.m(80179).exports
