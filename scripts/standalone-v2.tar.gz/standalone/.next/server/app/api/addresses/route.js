var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/addresses/route.js")
R.c("server/chunks/[root-of-the-server]__19516311._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_addresses_route_actions_366a0ac9.js")
R.m(95905)
module.exports=R.m(95905).exports
