var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/addresses/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__2067259c._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_addresses_[id]_route_actions_93638546.js")
R.m(22860)
module.exports=R.m(22860).exports
