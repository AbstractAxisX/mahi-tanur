:HL["/_next/static/chunks/dab4ec030d5743a3.css","style"]
:HL["/_next/static/chunks/4585faba3dad65ad.css","style"]
0:{"buildId":"t311eZD7Pj_BVXyq3mUz5","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"/_not-found","paramType":null,"paramKey":"/_not-found","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
