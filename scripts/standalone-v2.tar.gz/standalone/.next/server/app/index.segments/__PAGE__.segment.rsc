1:"$Sreact.fragment"
2:I[94628,["/_next/static/chunks/d64f8fdd0015d269.js","/_next/static/chunks/4cafaff8fb5607b5.js","/_next/static/chunks/6eec27fafcf6d1f9.js","/_next/static/chunks/ed18f00a6d92bf79.js","/_next/static/chunks/fc09ab20d04fe663.js"],"default"]
3:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"t311eZD7Pj_BVXyq3mUz5","rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/6eec27fafcf6d1f9.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/ed18f00a6d92bf79.js","async":true}],["$","script","script-2",{"src":"/_next/static/chunks/fc09ab20d04fe663.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
