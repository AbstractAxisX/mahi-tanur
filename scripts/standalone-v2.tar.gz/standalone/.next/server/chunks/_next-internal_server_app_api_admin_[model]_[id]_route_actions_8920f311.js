module.exports=[77463,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_%5Bmodel%5D_%5Bid%5D_route_actions_8920f311.js.map