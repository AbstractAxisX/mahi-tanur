module.exports=[5188,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_auth_admin_route_actions_3e0a8b67.js.map