module.exports=[7655,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_%5Bmodel%5D_route_actions_749d3f52.js.map